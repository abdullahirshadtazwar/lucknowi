const $ = (selector) => document.querySelector(selector);
const nav = $('#navigation');
$('.mobile-toggle').addEventListener('click', function () {
  const expanded = this.getAttribute('aria-expanded') === 'true';
  this.setAttribute('aria-expanded', String(!expanded));
  nav.classList.toggle('open', !expanded);
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open'); $('.mobile-toggle').setAttribute('aria-expanded', 'false');
}));
const searchDialog = $('#search-dialog');
const menuDialog = $('#menu-dialog');
function showDialog(dialog) { dialog.showModal(); document.body.style.overflow = 'hidden'; }
document.querySelectorAll('dialog').forEach(dialog => {
  dialog.querySelector('.close').addEventListener('click', () => dialog.close());
  dialog.addEventListener('close', () => { document.body.style.overflow = ''; });
  dialog.addEventListener('click', event => {
    const rect = dialog.getBoundingClientRect();
    if (event.target === dialog && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) dialog.close();
  });
});
const destinations = [
  { name: 'Nihari', keywords: 'beef slow cooked meat stew', href: '#food' },
  { name: 'Chicken Tangri Kebab', keywords: 'chicken grill kebabs', href: '#food' },
  { name: 'Dhaba Wali Dal', keywords: 'vegetarian lentils cream', href: '#food' },
  { name: 'Our story', keywords: 'about foodhouse interior dining', href: '#story' },
  { name: 'Visit us', keywords: 'contact facebook location hours restaurant', href: '#visit' }
];
function search() {
  const query = $('#search-input').value.trim().toLowerCase();
  const matches = destinations.filter(item => `${item.name} ${item.keywords}`.toLowerCase().includes(query));
  const results = $('#search-results'); results.replaceChildren();
  if (!matches.length) { const p = document.createElement('p'); p.textContent = 'No matches. Try a dish name, “story”, or “visit”.'; results.append(p); }
  matches.forEach(item => {
    const a = document.createElement('a'); a.href = item.href; a.textContent = item.name;
    const arrow = document.createElement('span'); arrow.textContent = '↗'; arrow.setAttribute('aria-hidden', 'true'); a.append(arrow);
    a.addEventListener('click', () => searchDialog.close()); results.append(a);
  });
}
$('#search-open').addEventListener('click', () => { showDialog(searchDialog); search(); $('#search-input').focus(); });
$('#search-input').addEventListener('input', search);
$('#menu-open').addEventListener('click', () => showDialog(menuDialog));
$('#menu-contact').addEventListener('click', () => menuDialog.close());
let toastTimer;
function toast(message) { $('#toast').textContent = message; $('#toast').classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => $('#toast').classList.remove('show'), 3500); }
$('#copy-link').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(location.href.split('#')[0]); toast('Website link copied.'); }
  catch { toast('Copy is unavailable here. You can copy the link from your address bar.'); }
});
$('#print').addEventListener('click', () => window.print());
$('#year').textContent = new Date().getFullYear();
function updateProgress() { const distance = document.documentElement.scrollHeight - innerHeight; $('.progress').style.width = `${distance > 0 ? scrollY / distance * 100 : 0}%`; }
addEventListener('scroll', updateProgress, { passive: true }); addEventListener('resize', updateProgress); addEventListener('load', updateProgress);
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => { if (entry.isIntersecting) nav.querySelectorAll('a').forEach(a => a.classList.toggle('active', a.hash === `#${entry.target.id}`)); });
}, { rootMargin: '-15% 0px -60% 0px' });
document.querySelectorAll('main section[id]').forEach(section => observer.observe(section));
