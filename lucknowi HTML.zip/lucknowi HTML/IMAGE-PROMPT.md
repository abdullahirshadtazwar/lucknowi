# Hero background

Generated with the built-in image generation tool using the two user-provided interior photos as references.

Saved asset: `assets/hero.png`

## Final prompt

Use case: photorealistic-natural. Asset type: wide restaurant website hero background, landscape 16:9. Generate a polished architectural photograph based on the two attached restaurant interior reference photos. Preserve the recognizable space: dark corrugated ceiling, warm woven rattan pendant lights, hanging green vines, brick wall accents, light gray textured walls with small arched niches and bare decorative branches, warm wooden tables and dark wooden chairs, cream tiled floor. An inviting quiet dining room before dinner service, no people. Eye-level wide angle with natural straight perspective, warm amber lighting and realistic materials. Palette: cream #e2d9c7, espresso brown #3c2b1f, deep burgundy #520f14 with natural green plants. Composition should work as a full-width background behind centered cream headline text, keep central detail calm. No text, logos, watermark, grain overlay or exaggerated luxury redesign.
